import { Layouts as Layout } from '@antv/layout/lib';
import TreeLayout from './tree-layout';
declare const registerLayout: (name: string, layoutOverride: any) => void;
export { TreeLayout, Layout, registerLayout };
