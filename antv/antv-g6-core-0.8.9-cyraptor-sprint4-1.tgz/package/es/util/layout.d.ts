export declare const isForce: (layoutType: any) => boolean;
