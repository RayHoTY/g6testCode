export declare const defaultSubjectColors: string[];
