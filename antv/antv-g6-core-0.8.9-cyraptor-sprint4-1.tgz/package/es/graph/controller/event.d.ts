import { IAbstractGraph } from '../../interface/graph';
export default abstract class EventController {
    protected graph: IAbstractGraph;
    destroyed: boolean;
    constructor(graph: IAbstractGraph);
    protected abstract initEvents(): void;
    abstract destroy(): void;
}
