import { Item } from '../../types';
import { IAbstractGraph } from '../../interface/graph';
export default class StateController {
    private graph;
    destroyed: boolean;
    constructor(graph: IAbstractGraph);
    /**
     * 更新 Item 的状态
     *
     * @param {Item} item Item实例
     * @param {string} state 状态名称
     * @param {boolean} enabled 状态是否可用
     * @memberof State
     */
    updateState(item: Item, state: string, enabled: string | boolean): void;
    /**
     * 批量更新 states，兼容 updateState，支持更新一个 state
     *
     * @param {Item} item
     * @param {(string | string[])} states
     * @param {boolean} enabled
     * @memberof State
     */
    updateStates(item: Item, states: string | string[], enabled: string | boolean): void;
    destroy(): void;
}
