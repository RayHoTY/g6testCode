import { GraphData } from '../../types';
import { IAbstractGraph } from '../../interface/graph';
export default abstract class LayoutController {
    graph: IAbstractGraph;
    destroyed: boolean;
    protected layoutCfg: any;
    protected layoutType: string | string[];
    protected layoutMethods: any;
    protected data: any;
    constructor(graph: IAbstractGraph);
    protected initLayout(): void;
    getLayoutType(): string | string[];
    protected getLayoutCfgType(layoutCfg: any): string | string[];
    protected isLayoutTypeSame(cfg: any): boolean;
    /**
     * @param {function} success callback
     * @return {boolean} 是否使用web worker布局
     */
    abstract layout(success?: () => void): boolean;
    refreshLayout(): void;
    abstract updateLayoutCfg(cfg: any): any;
    changeLayout(cfg: any): void;
    changeData(success: any): void;
    destoryLayoutMethods(): string[];
    destroyLayout(): void;
    setDataFromGraph(): GraphData;
    protected abstract execLayoutMethod(layoutCfg: any, order: any): Promise<void>;
    relayout(reloadData?: boolean): boolean;
    protected filterLayoutData(data: any, cfg: any): any;
    protected getLayoutBBox(nodes: any): {
        groupNodes: unknown[][];
        layoutNodes: any[];
    };
    layoutAnimate(): void;
    moveToZero(): void;
    /**
     * execute a preset layout before running layout
     */
    abstract initWithPreset(hasPresetCallback: any, noPresetCallback: any): Promise<void>;
    initPositions(center: any, nodes: any): Promise<void>;
    destroy(): void;
}
