import { IAbstractGraph } from '../../interface/graph';
import { ModeType, Modes } from '../../types';
export default class ModeController {
    private graph;
    destroyed: boolean;
    /**
     * modes = {
     *  default: [ 'drag-node', 'zoom-canvas' ],
     *  edit: [ 'drag-canvas', {
     *    type: 'brush-select',
     *    trigger: 'ctrl'
     *  }]
     * }
     *
     * @private
     * @type {Modes}
     * @memberof Mode
     */
    modes: Modes;
    /**
     * mode = 'drag-node'
     *
     * @private
     * @type {string}
     * @memberof Mode
     */
    mode: string;
    private currentBehaves;
    constructor(graph: IAbstractGraph);
    private formatModes;
    private setBehaviors;
    private static mergeBehaviors;
    private static filterBehaviors;
    setMode(mode: string): void;
    getMode(): string;
    /**
     * 动态增加或删除 Behavior
     *
     * @param {ModeType[]} behaviors
     * @param {(ModeType[] | ModeType)} modes
     * @param {boolean} isAdd
     * @returns {Mode}
     * @memberof Mode
     */
    manipulateBehaviors(behaviors: ModeType[] | ModeType, modes: string[] | string, isAdd: boolean): ModeController;
    /**
     * 更新行为参数
     * @param {string | ModeOption | ModeType} behavior 需要更新的行为
     * @param {string | string[]} modes 指定的模式中的行为，不指定则为 default
     * @return {Graph} Graph
     */
    updateBehavior(behavior: string | ModeType, newCfg: object, mode?: string): ModeController;
    destroy(): void;
}
