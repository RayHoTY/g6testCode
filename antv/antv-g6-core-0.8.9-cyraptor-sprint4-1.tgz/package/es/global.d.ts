declare const _default: {
    version: string;
    rootContainerClassName: string;
    nodeContainerClassName: string;
    edgeContainerClassName: string;
    comboContainerClassName: string;
    delegateContainerClassName: string;
    defaultLoopPosition: string;
    nodeLabel: {
        style: {
            fill: string;
            fontSize: number;
            textAlign: string;
            textBaseline: string;
        };
        offset: number;
    };
    defaultNode: {
        type: string;
        style: {
            lineWidth: number;
            stroke: string;
            fill: string;
        };
        size: number;
        color: string;
        linkPoints: {
            size: number;
            lineWidth: number;
            fill: string;
            stroke: string;
        };
    };
    nodeStateStyles: {
        active: {
            fill: string;
            stroke: string;
            lineWidth: number;
            shadowColor: string;
            shadowBlur: number;
        };
        selected: {
            fill: string;
            stroke: string;
            lineWidth: number;
            shadowColor: string;
            shadowBlur: number;
            'text-shape': {
                fontWeight: number;
            };
        };
        highlight: {
            fill: string;
            stroke: string;
            lineWidth: number;
            'text-shape': {
                fontWeight: number;
            };
        };
        inactive: {
            fill: string;
            stroke: string;
            lineWidth: number;
        };
        disable: {
            fill: string;
            stroke: string;
            lineWidth: number;
        };
    };
    edgeLabel: {
        style: {
            fill: string;
            textAlign: string;
            textBaseline: string;
            fontSize: number;
        };
    };
    defaultEdge: {
        type: string;
        size: number;
        style: {
            stroke: string;
            lineAppendWidth: number;
        };
        color: string;
    };
    edgeStateStyles: {
        active: {
            stroke: string;
            lineWidth: number;
        };
        selected: {
            stroke: string;
            lineWidth: number;
            shadowColor: string;
            shadowBlur: number;
            'text-shape': {
                fontWeight: number;
            };
        };
        highlight: {
            stroke: string;
            lineWidth: number;
            'text-shape': {
                fontWeight: number;
            };
        };
        inactive: {
            stroke: string;
            lineWidth: number;
        };
        disable: {
            stroke: string;
            lineWidth: number;
        };
    };
    comboLabel: {
        style: {
            fill: string;
            textBaseline: string;
            fontSize: number;
        };
        refY: number;
        refX: number;
    };
    defaultCombo: {
        type: string;
        style: {
            fill: string;
            lineWidth: number;
            stroke: string;
            r: number;
            width: number;
            height: number;
        };
        size: number[];
        color: string;
        padding: number[];
    };
    comboStateStyles: {
        active: {
            stroke: string;
            lineWidth: number;
            fill: string;
        };
        selected: {
            stroke: string;
            lineWidth: number;
            fill: string;
            shadowColor: string;
            shadowBlur: number;
            'text-shape': {
                fontWeight: number;
            };
        };
        highlight: {
            stroke: string;
            lineWidth: number;
            fill: string;
            'text-shape': {
                fontWeight: number;
            };
        };
        inactive: {
            stroke: string;
            fill: string;
            lineWidth: number;
        };
        disable: {
            stroke: string;
            fill: string;
            lineWidth: number;
        };
    };
    delegateStyle: {
        fill: string;
        fillOpacity: number;
        stroke: string;
        strokeOpacity: number;
        lineDash: number[];
    };
    windowFontFamily: string;
};
export default _default;
