import { Event as GraphEvent, ICanvas } from '@antv/g-base';
import { G6Event, IG6GraphEvent, IShapeBase, Item, BehaviorOption } from '../types';
import { IAbstractGraph } from './graph';
export interface IBehavior {
    registerBehavior: (type: string, behavior: BehaviorOption) => void;
    hasBehavior: (type: string) => boolean;
    getBehavior: (type: string) => any;
}
export interface IBehaviorOption {
    type: string;
    getEvents: () => {
        [key in G6Event]?: string;
    };
    updateCfg: (cfg: object) => {};
    getDefaultCfg?: () => object;
    shouldBegin?: (e?: IG6GraphEvent) => boolean;
    shouldUpdate?: (e?: IG6GraphEvent) => boolean;
    shouldEnd?: (e?: IG6GraphEvent) => boolean;
    bind?: (e: IAbstractGraph) => void;
    unbind?: (e: IAbstractGraph) => void;
}
export declare class G6GraphEvent extends GraphEvent implements IG6GraphEvent {
    item: Item;
    canvasX: number;
    canvasY: number;
    clientX: number;
    clientY: number;
    wheelDelta: number;
    detail: number;
    target: IShapeBase & ICanvas;
    [key: string]: unknown;
    constructor(type: string, event: IG6GraphEvent);
}
