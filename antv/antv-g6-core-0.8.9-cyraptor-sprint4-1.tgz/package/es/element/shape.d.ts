import { IGroup, IShape } from '@antv/g-base';
import { ShapeOptions, ShapeDefine } from '../interface/shape';
import { IPoint, Item, ModelConfig, UpdateType } from '../types';
/**
 * 工厂方法的基类
 * @type Shape.FactoryBase
 */
export declare const ShapeFactoryBase: {
    /**
     * 默认的形状，当没有指定/匹配 shapeType 时，使用默认的
     * @type {String}
     */
    defaultShapeType: string;
    /**
     * 形状的 className，用于搜索
     * @type {String}
     */
    className: any;
    /**
     * 获取绘制 Shape 的工具类，无状态
     * @param  {String} type 类型
     * @return {Shape} 工具类
     */
    getShape(type?: string): ShapeOptions;
    /**
     * 绘制图形
     * @param  {String} type  类型
     * @param  {Object} cfg 配置项
     * @param  {G.Group} group 图形的分组
     * @return {IShape} 图形对象
     */
    draw(type: string, cfg: ModelConfig, group: IGroup): IShape;
    /**
     * 更新
     * @param  {String} type  类型
     * @param  {Object} cfg 配置项
     * @param  {G6.Item} item 节点、边、分组等
     */
    baseUpdate(type: string, cfg: ModelConfig, item: Item, updateType?: UpdateType): void;
    /**
     * 设置状态
     * @param {String} type  类型
     * @param {String} name  状态名
     * @param {String | Boolean} value 状态值
     * @param {G6.Item} item  节点、边、分组等
     */
    setState(type: string, name: string, value: string | boolean, item: Item): void;
    /**
     * 是否允许更新，不重新绘制图形
     * @param  {String} type 类型
     * @return {Boolean} 是否允许使用更新
     */
    shouldUpdate(type: string): boolean;
    getControlPoints(type: string, cfg: ModelConfig): IPoint[] | undefined;
    /**
     * 获取控制点
     * @param {String} type 节点、边类型
     * @param  {Object} cfg 节点、边的配置项
     * @return {Array|null} 控制点的数组,如果为 null，则没有控制点
     */
    getAnchorPoints(type: string, cfg: ModelConfig): number[][] | undefined;
};
export default class Shape {
    static Node: any;
    static Edge: any;
    static Combo: any;
    static registerFactory(factoryType: string, cfg: object): object;
    static getFactory(factoryType: string): any;
    static registerNode(shapeType: string, nodeDefinition: ShapeOptions | ShapeDefine, extendShapeType?: string): any;
    static registerEdge(shapeType: string, edgeDefinition: ShapeOptions, extendShapeType?: string): any;
    static registerCombo(shapeType: string, comboDefinition: ShapeOptions, extendShapeType?: string): any;
}
