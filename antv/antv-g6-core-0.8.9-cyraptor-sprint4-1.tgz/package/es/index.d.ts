import AbstractGraph from './graph/graph';
import Shape, { Arrow, Marker } from './element';
import Util from './util';
import AbstractLayout from './graph/controller/layout';
import AbstractEvent from './graph/controller/event';
import Node from './item/node';
import Edge from './item/edge';
import Hull from './item/hull';
import Combo from './item/combo';
declare const registerNode: typeof Shape.registerNode;
declare const registerEdge: typeof Shape.registerEdge;
declare const registerCombo: typeof Shape.registerCombo;
declare const registerBehavior: (type: string, behavior: import("./types").BehaviorOption) => void;
declare const BaseGlobal: {
    version: string;
    rootContainerClassName: string;
    nodeContainerClassName: string;
    edgeContainerClassName: string;
    comboContainerClassName: string;
    delegateContainerClassName: string;
    defaultLoopPosition: string;
    nodeLabel: {
        style: {
            fill: string;
            fontSize: number;
            textAlign: string;
            textBaseline: string;
        };
        offset: number;
    };
    defaultNode: {
        type: string;
        style: {
            lineWidth: number;
            stroke: string;
            fill: string;
        };
        size: number;
        color: string;
        linkPoints: {
            size: number;
            lineWidth: number;
            fill: string;
            stroke: string;
        };
    };
    nodeStateStyles: {
        active: {
            fill: string;
            stroke: string;
            lineWidth: number;
            shadowColor: string;
            shadowBlur: number;
        };
        selected: {
            fill: string;
            stroke: string;
            lineWidth: number;
            shadowColor: string;
            shadowBlur: number;
            'text-shape': {
                fontWeight: number;
            };
        };
        highlight: {
            fill: string;
            stroke: string;
            lineWidth: number;
            'text-shape': {
                fontWeight: number;
            };
        };
        inactive: {
            fill: string;
            stroke: string;
            lineWidth: number;
        };
        disable: {
            fill: string;
            stroke: string;
            lineWidth: number;
        };
    };
    edgeLabel: {
        style: {
            fill: string;
            textAlign: string;
            textBaseline: string;
            fontSize: number;
        };
    };
    defaultEdge: {
        type: string;
        size: number;
        style: {
            stroke: string;
            lineAppendWidth: number;
        };
        color: string;
    };
    edgeStateStyles: {
        active: {
            stroke: string;
            lineWidth: number;
        };
        selected: {
            stroke: string;
            lineWidth: number;
            shadowColor: string;
            shadowBlur: number;
            'text-shape': {
                fontWeight: number;
            };
        };
        highlight: {
            stroke: string;
            lineWidth: number;
            'text-shape': {
                fontWeight: number;
            };
        };
        inactive: {
            stroke: string;
            lineWidth: number;
        };
        disable: {
            stroke: string;
            lineWidth: number;
        };
    };
    comboLabel: {
        style: {
            fill: string;
            textBaseline: string;
            fontSize: number;
        };
        refY: number;
        refX: number;
    };
    defaultCombo: {
        type: string;
        style: {
            fill: string;
            lineWidth: number;
            stroke: string;
            r: number;
            width: number;
            height: number;
        };
        size: number[];
        color: string;
        padding: number[];
    };
    comboStateStyles: {
        active: {
            stroke: string;
            lineWidth: number;
            fill: string;
        };
        selected: {
            stroke: string;
            lineWidth: number;
            fill: string;
            shadowColor: string;
            shadowBlur: number;
            'text-shape': {
                fontWeight: number;
            };
        };
        highlight: {
            stroke: string;
            lineWidth: number;
            fill: string;
            'text-shape': {
                fontWeight: number;
            };
        };
        inactive: {
            stroke: string;
            fill: string;
            lineWidth: number;
        };
        disable: {
            stroke: string;
            fill: string;
            lineWidth: number;
        };
    };
    delegateStyle: {
        fill: string;
        fillOpacity: number;
        stroke: string;
        strokeOpacity: number;
        lineDash: number[];
    };
    windowFontFamily: string;
};
export * from './types';
export { Arrow, Shape, Node, Edge, Combo, Hull, Marker, registerNode, registerCombo, AbstractGraph, Util, registerEdge, registerBehavior, AbstractLayout, AbstractEvent, BaseGlobal, };
declare const _default: {
    version: string;
    AbstractGraph: typeof AbstractGraph;
    BaseGlobal: {
        version: string;
        rootContainerClassName: string;
        nodeContainerClassName: string;
        edgeContainerClassName: string;
        comboContainerClassName: string;
        delegateContainerClassName: string;
        defaultLoopPosition: string;
        nodeLabel: {
            style: {
                fill: string;
                fontSize: number;
                textAlign: string;
                textBaseline: string;
            };
            offset: number;
        };
        defaultNode: {
            type: string;
            style: {
                lineWidth: number;
                stroke: string;
                fill: string;
            };
            size: number;
            color: string;
            linkPoints: {
                size: number;
                lineWidth: number;
                fill: string;
                stroke: string;
            };
        };
        nodeStateStyles: {
            active: {
                fill: string;
                stroke: string;
                lineWidth: number;
                shadowColor: string;
                shadowBlur: number;
            };
            selected: {
                fill: string;
                stroke: string;
                lineWidth: number;
                shadowColor: string;
                shadowBlur: number;
                'text-shape': {
                    fontWeight: number;
                };
            };
            highlight: {
                fill: string;
                stroke: string;
                lineWidth: number;
                'text-shape': {
                    fontWeight: number;
                };
            };
            inactive: {
                fill: string;
                stroke: string;
                lineWidth: number;
            };
            disable: {
                fill: string;
                stroke: string;
                lineWidth: number;
            };
        };
        edgeLabel: {
            style: {
                fill: string;
                textAlign: string;
                textBaseline: string;
                fontSize: number;
            };
        };
        defaultEdge: {
            type: string;
            size: number;
            style: {
                stroke: string;
                lineAppendWidth: number;
            };
            color: string;
        };
        edgeStateStyles: {
            active: {
                stroke: string;
                lineWidth: number;
            };
            selected: {
                stroke: string;
                lineWidth: number;
                shadowColor: string;
                shadowBlur: number;
                'text-shape': {
                    fontWeight: number;
                };
            };
            highlight: {
                stroke: string;
                lineWidth: number;
                'text-shape': {
                    fontWeight: number;
                };
            };
            inactive: {
                stroke: string;
                lineWidth: number;
            };
            disable: {
                stroke: string;
                lineWidth: number;
            };
        };
        comboLabel: {
            style: {
                fill: string;
                textBaseline: string;
                fontSize: number;
            };
            refY: number;
            refX: number;
        };
        defaultCombo: {
            type: string;
            style: {
                fill: string;
                lineWidth: number;
                stroke: string;
                r: number;
                width: number;
                height: number;
            };
            size: number[];
            color: string;
            padding: number[];
        };
        comboStateStyles: {
            active: {
                stroke: string;
                lineWidth: number;
                fill: string;
            };
            selected: {
                stroke: string;
                lineWidth: number;
                fill: string;
                shadowColor: string;
                shadowBlur: number;
                'text-shape': {
                    fontWeight: number;
                };
            };
            highlight: {
                stroke: string;
                lineWidth: number;
                fill: string;
                'text-shape': {
                    fontWeight: number;
                };
            };
            inactive: {
                stroke: string;
                fill: string;
                lineWidth: number;
            };
            disable: {
                stroke: string;
                fill: string;
                lineWidth: number;
            };
        };
        delegateStyle: {
            fill: string;
            fillOpacity: number;
            stroke: string;
            strokeOpacity: number;
            lineDash: number[];
        };
        windowFontFamily: string;
    };
    Util: {
        transform: typeof import("@antv/matrix-util/lib/ext").transform;
        mat3: typeof import("gl-matrix").mat3;
        isForce: (layoutType: any) => boolean;
        defaultSubjectColors: string[];
        compare: (attributeName: string) => (m: any, n: any) => number;
        getLineIntersect: (p0: import("@antv/g-base").Point, p1: import("@antv/g-base").Point, p2: import("@antv/g-base").Point, p3: import("@antv/g-base").Point) => import("@antv/g-base").Point;
        getRectIntersectByPoint: (rect: import("./types").IRect, point: import("@antv/g-base").Point) => import("@antv/g-base").Point;
        getCircleIntersectByPoint: (circle: import("./types").ICircle, point: import("@antv/g-base").Point) => import("@antv/g-base").Point;
        getEllipseIntersectByPoint: (ellipse: import("./types").IEllipse, point: import("@antv/g-base").Point) => import("@antv/g-base").Point;
        applyMatrix: (point: import("@antv/g-base").Point, matrix: import("./types").Matrix, tag?: 0 | 1) => import("@antv/g-base").Point;
        invertMatrix: (point: import("@antv/g-base").Point, matrix: import("./types").Matrix, tag?: 0 | 1) => import("@antv/g-base").Point;
        getCircleCenterByPoints: (p1: import("@antv/g-base").Point, p2: import("@antv/g-base").Point, p3: import("@antv/g-base").Point) => import("@antv/g-base").Point;
        distance: (p1: import("@antv/g-base").Point, p2: import("@antv/g-base").Point) => number;
        scaleMatrix: (matrix: import("./types").Matrix[], ratio: number) => import("./types").Matrix[];
        floydWarshall: (adjMatrix: import("./types").Matrix[]) => import("./types").Matrix[];
        getAdjMatrix: (data: import("./types").GraphData, directed: boolean) => import("./types").Matrix[];
        translate: (group: import("@antv/g-base").IGroup, vec: import("@antv/g-base").Point) => void;
        move: (group: import("@antv/g-base").IGroup, point: import("@antv/g-base").Point, animate?: boolean, animateCfg?: import("./types").GraphAnimateConfig) => void;
        scale: (group: import("@antv/g-base").IGroup, ratio: number | number[]) => void;
        rotate: (group: import("@antv/g-base").IGroup, angle: number) => void;
        getDegree: (n: number, nodeIdxMap: import("./types").NodeIdxMap, edges: import("./types").EdgeConfig[]) => number[];
        isPointInPolygon: (points: number[][], x: number, y: number) => boolean;
        intersectBBox: (box1: Partial<import("./types").IBBox>, box2: Partial<import("./types").IBBox>) => boolean;
        isPolygonsIntersect: (points1: number[][], points2: number[][]) => boolean;
        Line: typeof import("./util/math").Line;
        getBBoxBoundLine: (bbox: import("./types").IBBox, direction: string) => any;
        itemIntersectByLine: (item: import("./types").Item, line: import("./util/math").Line) => [import("./types").IPoint[], number];
        fractionToLine: (item: import("./types").Item, line: import("./util/math").Line) => number;
        getPointsCenter: (points: import("./types").IPoint[]) => import("./types").IPoint;
        squareDist: (a: import("./types").IPoint, b: import("./types").IPoint) => number;
        pointLineSquareDist: (point: import("./types").IPoint, line: import("./util/math").Line) => number;
        isPointsOverlap: (p1: any, p2: any, e?: number) => boolean;
        pointRectSquareDist: (point: import("@antv/g-base").Point, rect: import("./types").IRect) => number;
        pointLineDistance: (line: any, point: any) => number;
        lerp: (start: number, end: number, alpha: number) => number;
        lerpArray: (start: number[], end: number[], alpha: number) => number[];
        roundedHull(polyPoints: import("gl-matrix").vec2[], padding: number): string;
        paddedHull(polyPoints: import("gl-matrix").vec2[], padding: number): string | {
            x: number;
            y: number;
        }[];
        getSpline: (points: import("./types").IPoint[]) => import("@antv/path-util/lib/types").PathCommand[];
        getControlPoint: (startPoint: import("./types").IPoint, endPoint: import("./types").IPoint, percent?: number, offset?: number) => import("./types").IPoint;
        pointsToPolygon: (points: import("./types").IPoint[] | (string | {
            x: number;
            y: number;
        })[], z?: boolean) => string;
        pathToPoints: (path: any[]) => any[];
        getClosedSpline: (points: import("./types").IPoint[]) => any[];
        getStarPath: (outerR: number, innerR: number) => any[];
        getBBox: (element: import("./types").IShapeBase, group: import("@antv/g-base").IGroup) => import("./types").IBBox;
        getLoopCfgs: (cfg: import("./types").EdgeData) => import("./types").EdgeData;
        getLabelPosition: (pathShape: any, percent: number, refX: number, refY: number, rotate: boolean) => Partial<{
            rotate: number;
            textAlign: "center" | "left" | "right" | "start" | "end";
            angle: number;
            x: number;
            y: number;
            text: string;
            stroke: string;
            opacity: number;
            fontSize: number;
            fontStyle: "normal" | "italic" | "oblique";
            fontFamily: string;
            fontWeight: number | "bold" | "normal" | "bolder" | "lighter";
            fill: string;
            rotateCenter: string;
            lineWidth: number;
            shadowColor: string;
            shadowBlur: number;
            shadowOffsetX?: number;
            shadowOffsetY?: number;
            position: string;
            textBaseline: "top" | "middle" | "bottom" | "hanging" | "alphabetic" | "ideographic";
            offset: number;
            fillOpacity: number;
            background?: {
                fill?: string;
                stroke?: string;
                lineWidth?: number;
                radius?: number | number[];
                padding?: number | number[];
            };
        }>;
        traverseTree: <T extends {
            children?: T[];
        }>(data: T, fn: (data: T, parent: T, index: number) => boolean) => void;
        traverseTreeUp: <T_1 extends {
            children?: T_1[];
        }>(data: T_1, fn: (data: T_1, parent: T_1, index: number) => boolean) => void;
        getLetterWidth: (letter: any, fontSize: any) => number;
        getTextSize: (text: string, fontSize: number) => number[];
        truncateLabelByLength: (text: string, length: number) => string;
        plainCombosToTrees: (array: import("./types").ComboConfig[], nodes?: import("./types").NodeConfig[]) => import("./types").ComboTree[];
        reconstructTree: (trees: import("./types").ComboTree[], subtreeId?: string, newParentId?: string) => import("./types").ComboTree[];
        getComboBBox: (children: import("./types").ComboTree[], graph: import("./types").IAbstractGraph, combo?: import("./types").ICombo) => import("@antv/g-base").BBox;
        shouldRefreshEdge: (cfg: any) => any;
        cloneBesidesImg: (obj: any) => {};
        getAnimateCfgWithCallback: ({ animateCfg, callback, }: {
            animateCfg: import("./types").GraphAnimateConfig;
            callback: () => void;
        }) => import("./types").GraphAnimateConfig;
        uniqueId: (type: string) => string;
        formatPadding: (padding: import("./types").Padding) => number[];
        cloneEvent: (e: import("./types").IG6GraphEvent) => import("./types").IG6GraphEvent;
        isViewportChanged: (matrix: import("./types").Matrix) => boolean;
        isNaN: (input: any) => boolean;
        calculationItemsBBox: (items: import("./types").Item[]) => {
            x: number;
            y: number;
            width: number;
            height: number;
            minX: number;
            minY: number;
            maxX: number;
            maxY: number;
        };
        processParallelEdges: (edges: any, offsetDiff?: number, multiEdgeType?: string, singleEdgeType?: string, loopEdgeType?: string) => any;
    };
    Shape: typeof Shape;
    Node: typeof Node;
    Edge: typeof Edge;
    Combo: typeof Combo;
    Hull: typeof Hull;
    registerNode: typeof Shape.registerNode;
    registerEdge: typeof Shape.registerEdge;
    registerCombo: typeof Shape.registerCombo;
    registerBehavior: (type: string, behavior: import("./types").BehaviorOption) => void;
    Arrow: {
        triangle: (width?: number, length?: number, d?: number) => string;
        vee: (width?: number, length?: number, d?: number) => string;
        circle: (r?: number, d?: number) => string;
        rect: (width?: number, length?: number, d?: number) => string;
        diamond: (width?: number, length?: number, d?: number) => string;
        triangleRect: (tWidth?: number, tLength?: number, rWidth?: number, rLength?: number, gap?: number, d?: number) => string;
    };
    Marker: {
        collapse: (x: any, y: any, r: any) => any[][];
        expand: (x: any, y: any, r: any) => any[][];
        upTriangle: (x: any, y: any, r: any) => any[][];
        downTriangle: (x: any, y: any, r: any) => any[][];
    };
    AbstractLayout: typeof AbstractLayout;
    AbstractEvent: typeof AbstractEvent;
};
export default _default;
