import { IAbstractGraph } from '../interface/graph';
declare const _default: {
    getDefaultCfg(): {};
    /**
     * register event handler, behavior will auto bind events
     * for example:
     * return {
     *  click: 'onClick'
     * }
     */
    getEvents(): {};
    updateCfg(cfg: object): boolean;
    shouldBegin(): boolean;
    shouldUpdate(): boolean;
    shouldEnd(): boolean;
    /**
     * auto bind events when register behavior
     * @param graph Graph instance
     */
    bind(graph: IAbstractGraph): void;
    unbind(graph: IAbstractGraph): void;
    get(val: string): any;
    set(key: string, val: any): any;
};
export default _default;
