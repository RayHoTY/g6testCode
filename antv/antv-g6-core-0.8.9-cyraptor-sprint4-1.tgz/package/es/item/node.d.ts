import { IEdge, INode } from '../interface/item';
import { IPoint, ModelConfig, UpdateType } from '../types';
import Item from './item';
export default class Node extends Item implements INode {
    getNearestPoint(points: IPoint[], curPoint: IPoint): IPoint;
    getDefaultCfg(): {
        type: string;
        edges: any[];
    };
    /**
     * 获取从节点关联的所有边
     */
    getEdges(): IEdge[];
    /**
     * 获取所有的入边
     */
    getInEdges(): IEdge[];
    /**
     * 获取所有的出边
     */
    getOutEdges(): IEdge[];
    /**
     * 获取节点的邻居节点
     *
     * @returns {INode[]}
     * @memberof Node
     */
    getNeighbors(type?: 'target' | 'source' | undefined): INode[];
    /**
     * 根据锚点的索引获取连接点
     * @param  {Number} index 索引
     */
    getLinkPointByAnchor(index: number): IPoint;
    /**
     * 获取连接点
     * @param point
     */
    getLinkPoint(point: IPoint): IPoint | null;
    /**
     * 获取锚点的定义
     * @return {array} anchorPoints
     */
    getAnchorPoints(): IPoint[];
    /**
     * add edge
     * @param edge Edge instance
     */
    addEdge(edge: IEdge): void;
    /**
     * 锁定节点
     */
    lock(): void;
    /**
     * 解锁锁定的节点
     */
    unlock(): void;
    hasLocked(): boolean;
    /**
     * 移除边
     * @param {Edge} edge 边
     */
    removeEdge(edge: IEdge): void;
    clearCache(): void;
    /**
     * 判断更新的种类，move 表示仅移动，bbox 表示大小有变化，style 表示仅与大小无关的参数变化
     * @param cfg 节点数据模型
     */
    getUpdateType(cfg?: ModelConfig): UpdateType;
    setState(state: string, value: string | boolean): void;
    clearStates(states?: string | string[]): void;
    private runWithBBoxAffected;
}
