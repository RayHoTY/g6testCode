/**
 * 通过配置不同的 costFunc, distFunc, constraints 可以得到不同效果的 router
 * generalRouter: 不限制搜索时的移动方向，避开障碍即可
 * orthogonal: 线必须沿着竖直或水平方向（4个方向）
 * octolinearRouter: 线沿着竖直、水平、对角线方向（8个方向）
 */
import { INode, Item } from '@antv/g6-core';
import { PolyPoint } from './polyline-util';
export interface RouterCfg {
    offset?: number;
    gridSize?: number;
    obstacles?: Item[];
    maxAllowedDirectionChange?: number;
    directions?: any[];
    startDirections?: string[];
    penalties?: {};
    simple?: boolean;
    distFunc?: (p1: PolyPoint, p2: PolyPoint) => number;
    fallbackRoute?: (p1: PolyPoint, p2: PolyPoint, startNode?: INode, endNode?: INode, cfg?: RouterCfg) => PolyPoint[];
    maximumLoops?: number;
}
export declare const octolinearCfg: RouterCfg;
export declare const pathFinder: (startPoint: PolyPoint, endPoint: PolyPoint, startNode: INode, endNode: INode, routerCfg?: RouterCfg) => PolyPoint[];
