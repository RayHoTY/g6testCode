import G6 from '@antv/g6-pc';
export * from '@antv/g6-pc';
export default G6;
export declare const version = "4.8.9";
