import { IG6GraphEvent } from '@antv/g6-core';
import Base, { IPluginBaseConfig } from '../base';
interface TooltipConfig extends IPluginBaseConfig {
    getContent?: (evt?: IG6GraphEvent) => HTMLDivElement | string;
    offsetX?: number;
    offsetY?: number;
    shouldBegin?: (evt?: IG6GraphEvent) => boolean;
    itemTypes?: string[];
    trigger?: 'mouseenter' | 'click';
    fixToNode?: [number, number] | undefined;
}
export default class Tooltip extends Base {
    constructor(config?: TooltipConfig);
    private currentTarget;
    getDefaultCfgs(): TooltipConfig;
    getEvents(): {
        'node:click': string;
        'edge:click': string;
        'combo:click': string;
        'canvas:click': string;
        afterremoveitem: string;
        contextmenu: string;
        drag: string;
        'node:mouseenter'?: undefined;
        'node:mouseleave'?: undefined;
        'node:mousemove'?: undefined;
        'edge:mouseenter'?: undefined;
        'edge:mouseleave'?: undefined;
        'edge:mousemove'?: undefined;
        'combo:mouseenter'?: undefined;
        'combo:mouseleave'?: undefined;
        'combo:mousemove'?: undefined;
        'node:drag'?: undefined;
    } | {
        'node:mouseenter': string;
        'node:mouseleave': string;
        'node:mousemove': string;
        'edge:mouseenter': string;
        'edge:mouseleave': string;
        'edge:mousemove': string;
        'combo:mouseenter': string;
        'combo:mouseleave': string;
        'combo:mousemove': string;
        afterremoveitem: string;
        contextmenu: string;
        'node:drag': string;
        'node:click'?: undefined;
        'edge:click'?: undefined;
        'combo:click'?: undefined;
        'canvas:click'?: undefined;
        drag?: undefined;
    };
    init(): void;
    onClick(e: IG6GraphEvent): void;
    onMouseEnter(e: IG6GraphEvent): void;
    onMouseMove(e: IG6GraphEvent): void;
    onMouseLeave(): void;
    clearContainer(): void;
    showTooltip(e: IG6GraphEvent): void;
    hideTooltip(): void;
    updatePosition(e: IG6GraphEvent): void;
    hide(): void;
    destroy(): void;
}
export {};
