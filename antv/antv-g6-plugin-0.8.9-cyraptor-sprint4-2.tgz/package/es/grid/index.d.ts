import { ViewPortEventParam } from '@antv/g6-core';
import Base from '../base';
interface GridConfig {
    img?: string;
    /** 网格是否跟随视图移动 */
    follow?: boolean;
}
export default class Grid extends Base {
    constructor(config?: GridConfig);
    getDefaultCfgs(): GridConfig;
    init(): void;
    /** 定位信息初始化 */
    positionInit(): void;
    getEvents(): {
        viewportchange: string;
    };
    /**
     * viewport change 事件的响应函数
     * @param param
     */
    protected updateGrid(param: ViewPortEventParam): void;
    getContainer(): HTMLDivElement;
    destroy(): void;
}
export {};
