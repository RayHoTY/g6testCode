import { IG6GraphEvent, Item } from '@antv/g6-core';
import Base, { IPluginBaseConfig } from '../base';
interface MenuConfig extends IPluginBaseConfig {
    handleMenuClick?: (target: HTMLElement, item: Item) => void;
    getContent?: (evt?: IG6GraphEvent) => HTMLDivElement | string;
    offsetX?: number;
    offsetY?: number;
    shouldBegin?: (evt?: IG6GraphEvent) => boolean;
    itemTypes?: string[];
    trigger?: 'click' | 'contextmenu';
}
export default class Menu extends Base {
    constructor(config?: MenuConfig);
    getDefaultCfgs(): MenuConfig;
    getEvents(): {
        click: string;
        touchend: string;
        contextmenu?: undefined;
    } | {
        contextmenu: string;
        click?: undefined;
        touchend?: undefined;
    };
    init(): void;
    protected onMenuShow(e: IG6GraphEvent): void;
    private removeMenuEventListener;
    private onMenuHide;
    destroy(): void;
}
export {};
