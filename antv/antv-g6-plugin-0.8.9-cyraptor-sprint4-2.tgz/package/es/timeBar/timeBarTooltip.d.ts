export declare const BACKGROUND_STYLE: {
    opacity: number;
    fill: string;
};
export declare const ARROW_STYLE: {
    opacity: number;
    fill: string;
    r: number;
};
export declare const TEXT_STYLE: {
    fill: string;
    fontSize: number;
};
export interface TimeBarTooltipCfg {
    readonly container: HTMLElement | string;
    readonly className?: string;
    readonly x?: number;
    readonly y?: number;
    readonly width?: number;
    readonly height?: number;
    readonly padding?: number[];
    readonly text?: string;
    readonly backgroundColor?: string;
    readonly textColor?: string;
    readonly opacity?: number;
    readonly fontSize?: number;
}
/**
 * 缩略趋势图
 */
export default class TimeBarTooltip {
    private container;
    private className;
    backgroundDOM: HTMLElement;
    arrowDOM: HTMLElement;
    private x;
    private y;
    private padding;
    private backgroundColor;
    private textColor;
    private parentHeight;
    private parentWidth;
    private opacity;
    private fontSize;
    private text;
    constructor(cfg?: TimeBarTooltipCfg);
    /**
     * 首次渲染
     * @private
     */
    private render;
    show(cfg: any): void;
    hide(): void;
}
