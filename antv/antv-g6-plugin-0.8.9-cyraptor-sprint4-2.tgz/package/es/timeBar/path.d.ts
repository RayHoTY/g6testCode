type Point = [number, number];
/**
 * 将点连接成路径 path
 * @param points
 */
export declare function getLinePath(points: Point[]): any[][];
/**
 * 将点连成平滑的曲线
 * @param points
 */
export declare function getSmoothLinePath(points: Point[]): any[][];
/**
 * 将数据转成 path，利用 scale 的归一化能力
 * @param data
 * @param width
 * @param height
 * @param smooth
 */
export declare function dataToPath(data: number[], width: number, height: number, smooth?: boolean): any[][];
export declare function dataToRectPath(data: number[], width: number, height: number, barWidth?: number): any[][];
/**
 * 获得 area 面积的横向连接线的 px 位置
 * @param data
 * @param width
 * @param height
 */
export declare function getAreaLineY(data: number[], height: number): number;
/**
 * 线 path 转 area path
 * @param path
 * @param width
 * @param height
 */
export declare function linePathToAreaPath(path: any[][], width: number, height: number, data: number[]): any[][];
/**
 * @ignore
 * 根据数据点生成矩形的四个关键点
 * @param pointInfo 数据点信息
 * @returns rect points 返回矩形四个顶点信息
 */
export declare function getRectPoints(pointInfo: any): {
    x: number;
    y: number;
}[];
/**
 * @ignore
 * 根据矩形关键点绘制 path
 * @param points 关键点数组
 * @param isClosed path 是否需要闭合
 * @returns 返回矩形的 path
 */
export declare function getRectPath(points: {
    x: number;
    y: number;
}[], isClosed?: boolean): any[];
export {};
