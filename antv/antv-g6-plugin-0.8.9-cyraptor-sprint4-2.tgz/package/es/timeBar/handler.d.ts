import { IGroup } from '@antv/g-base';
interface IStyle {
    fill?: string;
    stroke?: string;
    radius?: number;
    opacity?: number;
    cursor?: string;
    highLightFill?: string;
}
export interface HandlerCfg {
    group: IGroup;
    name: string;
    type: 'trend' | 'simple';
    readonly x: number;
    readonly y: number;
    readonly width: number;
    readonly height: number;
    readonly style?: IStyle;
}
export default class Handler {
    private group;
    private name;
    private x;
    private y;
    private width;
    private height;
    private style;
    private handleType;
    private verticalLine;
    private topCircle;
    private bottomCircle;
    private handleGroup;
    constructor(cfg: HandlerCfg);
    /**
     * 设置位置 x
     * @param x
     */
    setX(x: number): void;
    /**
     * 设置位置 y
     * @param y
     */
    setY(y: number): void;
    setXY(x: number, y: number): void;
    /**
     * 初始化组件
     * @private
     */
    private renderHandle;
    private bindSimpleEvents;
    private bindTrendEvents;
    show(): void;
    hide(): void;
    private updateXY;
}
export {};
