/**
 * 基于 G 的按钮组件
 */
import { IGroup } from '@antv/g-base';
import { ExtendedShapeStyle } from './constant';
/** 播放按钮配置 */
interface ButtonCfg {
    group: IGroup;
    /** 按钮位置数据 */
    readonly x: number;
    readonly y: number;
    readonly r: number;
    readonly isPlay: boolean;
    readonly style: ExtendedShapeStyle;
}
export default class Button {
    /** button 配置 */
    private config;
    /** 圆点 */
    private circle;
    /** 开始 marker */
    private startMarker;
    /** 暂停 marker */
    private pauseMarkerGroup;
    private startMarkerGroup;
    private pauseLeftMarker;
    private pauseRightMarker;
    constructor(cfg: ButtonCfg);
    update(cfg: Partial<ButtonCfg>): void;
    private init;
    private initElement;
    private updateElement;
    private renderMarker;
    /** 获取播放键 marker path */
    private getStartMarkerPath;
}
export {};
