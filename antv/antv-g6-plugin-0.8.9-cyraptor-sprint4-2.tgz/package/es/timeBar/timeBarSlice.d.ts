import { ICanvas, IGroup } from '@antv/g-base';
import { ShapeStyle, IAbstractGraph as IGraph } from '@antv/g6-core';
import { ControllerCfg } from './controllerBtn';
export interface TimeBarSliceOption {
    readonly x?: number;
    readonly y?: number;
    readonly width?: number;
    readonly height?: number;
    readonly padding?: number;
    readonly selectedTickStyle?: ShapeStyle;
    readonly unselectedTickStyle?: ShapeStyle;
    readonly tooltipBackgroundColor?: string;
    readonly start?: number;
    readonly end?: number;
    readonly data: {
        date: string;
        value: string;
    }[];
    readonly tickLabelFormatter?: (d: any) => string | boolean;
    readonly tooltipFomatter?: (d: any) => string;
}
export interface TimeBarSliceConfig extends TimeBarSliceOption {
    readonly graph: IGraph;
    readonly group: IGroup;
    readonly canvas: ICanvas;
    readonly x: number;
    readonly y: number;
    readonly tickLabelStyle?: Object;
    readonly controllerCfg?: ControllerCfg;
}
export default class TimeBarSlice {
    private graph;
    private canvas;
    private group;
    private sliceGroup;
    private width;
    private height;
    private padding;
    private data;
    private start;
    private end;
    x: number;
    y: number;
    private selectedTickStyle;
    private unselectedTickStyle;
    private tickLabelFormatter;
    private tickLabelStyle?;
    private tickRects;
    private tickWidth;
    private startTickRectId;
    private endTickRectId;
    private tooltipBackgroundColor;
    private tooltipFomatter;
    private dragging;
    private controllerBtnGroup;
    /** 是否处于播放状态 */
    private isPlay;
    private currentSpeed;
    /** 动画 id */
    private playHandler;
    private frameCount;
    private fontFamily;
    private controllerCfg;
    constructor(cfgs?: TimeBarSliceConfig);
    private renderSlices;
    private initEvent;
    private changePlayStatus;
    private startPlay;
    private updateStartEnd;
    destory(): void;
}
