import { IGroup } from '@antv/g-base';
import { ShapeStyle } from '@antv/g6-core';
export declare const LINE_STYLE: {
    stroke: string;
    strokeOpacity: number;
};
export declare const AREA_STYLE: {
    fill: string;
    opacity: number;
};
export interface Interval {
    data: number[];
    style: ShapeStyle;
}
export interface TrendCfg {
    readonly group: IGroup;
    readonly x?: number;
    readonly y?: number;
    readonly width?: number;
    readonly height?: number;
    readonly data?: number[];
    readonly smooth?: boolean;
    readonly isArea?: boolean;
    readonly lineStyle?: ShapeStyle;
    readonly areaStyle?: ShapeStyle;
    readonly interval?: Interval;
}
/**
 * 缩略趋势图
 */
export default class Trend {
    private group;
    private x;
    private y;
    private width;
    private height;
    private barWidth;
    private data;
    private smooth;
    private isArea;
    private lineStyle;
    private areaStyle;
    private intervalConfig;
    constructor(cfg: TrendCfg);
    /**
     * 构造
     * @private
     */
    private renderLine;
    destory(): void;
}
