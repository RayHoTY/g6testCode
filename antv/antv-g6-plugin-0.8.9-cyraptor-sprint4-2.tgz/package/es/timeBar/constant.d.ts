import { ShapeStyle } from '@antv/g6-core';
export declare const TIMELINE_START = "timebarstartplay";
export declare const TIMELINE_END = "timebarendplay";
export declare const VALUE_CHANGE = "valuechange";
export declare const TIMEBAR_CONFIG_CHANGE = "timebarConfigChanged";
export declare const PLAY_PAUSE_BTN = "playPauseBtn";
export declare const NEXT_STEP_BTN = "nextStepBtn";
export declare const PRE_STEP_BTN = "preStepBtn";
export interface ExtendedShapeStyle extends ShapeStyle {
    scale?: number;
    offsetX?: number;
    offsetY?: number;
}
