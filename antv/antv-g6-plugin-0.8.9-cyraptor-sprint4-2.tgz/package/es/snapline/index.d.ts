import { ShapeStyle } from '@antv/g6-core';
import Base, { IPluginBaseConfig } from '../base';
interface SnapLineConfig extends IPluginBaseConfig {
    line?: ShapeStyle;
    itemAlignType?: boolean | 'horizontal' | 'vertical' | 'center';
}
export default class SnapLine extends Base {
    constructor(props?: SnapLineConfig);
    getDefaultCfgs(): {
        line: {
            stroke: string;
            lineWidth: number;
        };
        /**
         * item align type
         * @type {String|True|False}
         */
        itemAlignType: string;
        /**
         * tolerance to item force align
         * @type {String|True|False}
         */
        tolerance: number;
        horizontalLines: {};
        verticalLines: {};
        alignLines: any[];
    };
    init(): void;
    getEvents(): {
        'node:dragstart': string;
        'node:drag': string;
        'node:dragend': string;
    };
    onDragStart(): void;
    onDrag(e: any): void;
    onDragEnd(): void;
    /**
     * 每次开始拖动之前，计算出所有节点在水平和垂直方向上，左中右三条中线，并缓存起来
     *
     * @param {object} item Node节点
     * @memberof AlignLine
     */
    initBoxLine(): void;
    /**
     * 显示AlignLine
     *
     * @param {object} point 起始点
     * @param {object} bbox BBox
     * @returns
     * @memberof AlignLine
     */
    show(point: any, bbox: any): any;
    /**
     * 拖动拖出中添加辅助线
     *
     * @param {object} point 起始点
     * @param {object} bbox 代理形状的bbox
     * @param {object} originPoint 原始点，同point
     * @memberof AlignLine
     */
    private itemAlign;
    /**
     * 根据配置项添加辅助线
     *
     * @param {object} cfg
     * @memberof AlignLine
     */
    private addAlignLine;
    /**
     * 获取点到线的距离
     *
     * @param {array} line [x1, y1, x2, y2] 线的四个点
     * @param {object} point 点的x和y坐标点 {x, y}
     * @returns
     * @memberof AlignLine
     */
    private getLineDisObject;
    getContainer(): HTMLDivElement;
    /**
     * 拖动过程中，清楚上次绘制的线
     *
     * @memberof AlignLine
     */
    clearAlignLine(): void;
    /**
     * 拖动结束时候，情况缓存的节点的辅助线，同时删除绘制的线
     *
     * @memberof AlignLine
     */
    destory(): void;
}
export {};
