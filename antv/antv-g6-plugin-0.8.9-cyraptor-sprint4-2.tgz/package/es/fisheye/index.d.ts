import { IG6GraphEvent, ShapeStyle } from '@antv/g6-core';
import Base from '../base';
interface FisheyeConfig {
    trigger?: 'mousemove' | 'click' | 'drag';
    d?: number;
    r?: number;
    delegateStyle?: ShapeStyle;
    showLabel?: boolean;
    scaleRBy?: 'wheel' | 'drag' | 'unset' | undefined;
    scaleDBy?: 'wheel' | 'drag' | 'unset' | undefined;
    maxR?: number;
    minR?: number;
    maxD?: number;
    minD?: number;
    showDPercent?: boolean;
}
export default class Fisheye extends Base {
    constructor(config?: FisheyeConfig);
    getDefaultCfgs(): FisheyeConfig;
    getEvents(): any;
    init(): void;
    protected createDelegate(e: IG6GraphEvent): void;
    /**
     * Scale the range by wheel
     * @param e mouse wheel event
     */
    protected scaleRByWheel(e: IG6GraphEvent): void;
    /**
     * Scale the range by dragging
     * @param e mouse event
     */
    protected scaleRByDrag(e: IG6GraphEvent): void;
    /**
     * Scale the magnifying factor by wheel
     * @param e mouse wheel event
     */
    protected scaleDByWheel(evt: IG6GraphEvent): void;
    /**
     * Scale the magnifying factor by dragging
     * @param e mouse event
     */
    protected scaleDByDrag(e: IG6GraphEvent): void;
    /**
     * Response function for mousemove, click, or drag to magnify
     * @param e mouse event
     */
    protected magnify(e: IG6GraphEvent, mousePos?: any): void;
    /**
     * Restore the cache nodes while magnifying
     */
    protected restoreCache(): void;
    /**
     * Adjust part of the parameters, including trigger, d, r, maxR, minR, maxD, minD, scaleRBy, and scaleDBy
     * @param {FisheyeConfig} cfg
     */
    updateParams(cfg: FisheyeConfig): void;
    /**
     * Update the delegate shape of the lens
     * @param {Point} mCenter the center of the shape
     * @param {number} r the radius of the shape
     */
    private updateDelegate;
    /**
     * Clear the fisheye lens
     */
    clear(): void;
    /**
     * Destroy the component
     */
    destroy(): void;
}
export {};
