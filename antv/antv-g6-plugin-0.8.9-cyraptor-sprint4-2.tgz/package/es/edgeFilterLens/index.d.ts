import { IG6GraphEvent, ShapeStyle } from '@antv/g6-core';
import Base from '../base';
interface EdgeFilterLensConfig {
    trigger?: 'mousemove' | 'click' | 'drag';
    r?: number;
    delegateStyle?: ShapeStyle;
    showLabel?: 'node' | 'edge' | 'both' | undefined;
    scaleRBy?: 'wheel' | undefined;
    maxR?: number;
    minR?: number;
    type?: 'one' | 'both' | 'only-source' | 'only-target';
    shouldShow?: (d?: unknown) => boolean;
}
export default class EdgeFilterLens extends Base {
    constructor(config?: EdgeFilterLensConfig);
    getDefaultCfgs(): EdgeFilterLensConfig;
    getEvents(): any;
    init(): void;
    protected createDelegate(e: IG6GraphEvent): void;
    /**
     * Scale the range by wheel
     * @param e mouse wheel event
     */
    protected scaleRByWheel(e: IG6GraphEvent): void;
    /**
     * Response function for mousemove, click, or drag to filter out the edges
     * @param e mouse event
     */
    protected filter(e: IG6GraphEvent): void;
    /**
     * Adjust part of the parameters, including trigger, type, r, maxR, minR, shouldShow, showLabel, and scaleRBy
     * @param {EdgeFilterLensConfig} cfg
     */
    updateParams(cfg: EdgeFilterLensConfig): void;
    /**
     * Update the delegate shape of the lens
     * @param {Point} mCenter the center of the shape
     * @param {number} r the radius of the shape
     */
    private updateDelegate;
    /**
     * Clear the filtering
     */
    clear(): void;
    /**
     * Destroy the component
     */
    destroy(): void;
}
export {};
