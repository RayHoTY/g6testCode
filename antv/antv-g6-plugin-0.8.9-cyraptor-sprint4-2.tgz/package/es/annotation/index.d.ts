import { ShapeStyle } from '@antv/g6-core';
import Base from '../base';
interface AnnotationConfig {
    trigger?: 'click' | 'fix';
    containerCfg?: {
        position?: 'left' | 'right' | 'top' | 'bottom';
        className?: string;
        width?: number;
        height?: number;
        offsetX?: number;
        offsetY?: number;
    };
    editable?: boolean;
    itemHighlightState?: string;
    defaultData?: CardCfg[];
    cardCfg?: CardCfg;
    linkStyle?: ShapeStyle;
    linkHighlightStyle?: ShapeStyle;
    getTitle?: (item: any) => string | HTMLDivElement;
    getContent?: (item: any) => string | HTMLDivElement;
    getTitlePlaceholder?: (item: any) => string | HTMLDivElement;
    getContentPlaceholder?: (item: any) => string | HTMLDivElement;
    onAnnotationChange?: (info: any, action: string) => void;
}
interface CardCfg {
    id?: string;
    width?: number | 'fit-content';
    height?: number | 'fit-content';
    minHeight?: number | string;
    minWidth?: number | string;
    collapsed?: boolean;
    x?: number;
    y?: number;
    title?: string;
    content?: string;
    borderRadius?: number;
    maxTitleLength?: number;
    maxWidth?: number;
    collapseType?: 'minimize' | 'hide';
    closeType?: 'hide' | 'remove';
    defaultBegin?: {
        left?: number;
        top?: number;
        right?: number;
        bottom?: number;
    };
    onMouseEnterIcon?: (evt: any, id: string, type: 'expand' | 'collapse' | 'close') => void;
    onMouseLeaveIcon?: (evt: any, id: string, type: 'expand' | 'collapse' | 'close') => void;
    onClickIcon?: (evt: any, id: string, type: 'expand' | 'collapse' | 'close') => void;
}
export default class Annotation extends Base {
    constructor(config?: AnnotationConfig);
    getDefaultCfgs(): AnnotationConfig;
    getEvents(): {
        [eventName: string]: string;
    };
    private getDOMContent;
    init(): void;
    private createContainer;
    private resizeCanvas;
    /**
     * 更新超出视口范围的卡片位置
     * @param selfObj 当前 annotation 插件对象。外部调用不需要传入该参数
     */
    updateOutsideCards(selfObj: any): void;
    showAnnotation(evt: any): void;
    hideCards(): void;
    toggleAnnotation(item: any, cfg?: CardCfg): void;
    updateCardPositionsInConatainer(): void;
    handleExpandCollapseCard(id: any): void;
    /**
     * 隐藏标注卡片，下次打开还保留隐藏前的配置，包括文本内容、位置等
     * @param id 卡片 id，即元素(节点/边)的 id
     * @returns
     */
    hideCard(id: any): void;
    /**
     * 移除标注卡片，下一次生成时将被初始化
     * @param id 卡片 id，即元素(节点/边)的 id
     * @returns
     */
    removeCard(id: any): void;
    private bindListener;
    updateCardSize(id: any): void;
    updateLink({ item }: {
        item: any;
    }): void;
    updateLinks(): void;
    onGraphDataChange(): void;
    onGraphItemVisibilityChange({ item, visible }: {
        item: any;
        visible: any;
    }): void;
    saveData(saveClosed?: boolean): any[];
    readData(data: any): void;
    /**
     * Clear the cards and links
     */
    clear(): void;
    /**
     * Destroy the component
     */
    destroy(): void;
}
export {};
