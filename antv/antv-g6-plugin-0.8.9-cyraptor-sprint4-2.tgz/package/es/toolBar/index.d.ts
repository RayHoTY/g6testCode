import Base, { IPluginBaseConfig } from '../base';
import { IAbstractGraph as IGraph } from '@antv/g6-core';
import { Point } from '@antv/g-base';
interface ToolBarConfig extends IPluginBaseConfig {
    handleClick?: (code: string, graph: IGraph) => void;
    getContent?: (graph?: IGraph) => HTMLDivElement | string;
    position?: Point | null;
    zoomSensitivity?: number;
    minZoom?: number;
    maxZoom?: number;
}
export default class ToolBar extends Base {
    constructor(config?: ToolBarConfig);
    getDefaultCfgs(): ToolBarConfig;
    init(): void;
    private bindUndoRedo;
    /**
     * undo 操作
     */
    undo(): void;
    /**
     * redo 操作
     */
    redo(): void;
    /**
     * zoomOut 操作
     */
    zoomOut(): void;
    /**
     * zoomIn 操作
     */
    zoomIn(): void;
    /**
     * realZoom 操作
     */
    realZoom(): void;
    /**
     * autoZoom 操作
     */
    autoZoom(): void;
    /**
     * 根据 Toolbar 上不同类型对图进行操作
     * @param code 操作类型编码
     * @param graph Graph 实例
     */
    handleDefaultOperator(code: string): void;
    destroy(): void;
}
export {};
