import { GraphData, ShapeStyle } from '@antv/g6-core';
import Base from '../base';
interface LegendConfig {
    data: GraphData;
    position?: 'top' | 'top-left' | 'top-right' | 'right' | 'right-top' | 'right-bottom' | 'left' | 'left-top' | 'left-bottom' | 'bottom' | 'bottom-left' | 'bottom-right';
    padding?: number | number[];
    margin?: number | number[];
    offsetX?: number;
    offsetY?: number;
    containerStyle?: ShapeStyle;
    flipPage?: boolean;
    horiSep?: number;
    vertiSep?: number;
    layout?: 'vertical' | 'horizontal';
    width?: number | 'fit-content';
    height?: number | 'fit-content';
    align?: 'center' | 'right' | 'left';
    title?: string;
    titleConfig?: {
        position?: 'center' | 'right' | 'left';
        offsetX?: number;
        offsetY?: number;
        [key: string]: unknown;
    };
    filter?: {
        enable?: boolean;
        multiple?: boolean;
        trigger?: 'click' | 'mouseenter';
        legendStateStyles?: {
            active?: ShapeStyle;
            inactive?: ShapeStyle;
        };
        graphActiveState?: string;
        graphInactiveState?: string;
        filterFunctions?: {
            [key: string]: (d: any) => boolean;
        };
    };
}
export default class Legend extends Base {
    constructor(config?: LegendConfig);
    getDefaultCfgs(): LegendConfig;
    init(): void;
    protected getContainerPos(size?: number[]): any;
    bindEvents(): void;
    /**
     * 更新 legend 数据，开放给用户控制
     * @param param
     */
    changeData(data: GraphData): void;
    activateLegend(shape: any): void;
    private findLegendItemsByState;
    clearActiveLegend(): void;
    /**
     * 高亮和置灰图例，并过滤主图元素
     * @param param
     */
    filterData(e: any): void;
    /**
     * 清除主图相关状态
     * @param param
     */
    clearFilter(): void;
    /**
     * 渲染 legend 图
     * @param param
     */
    protected render(): number[];
    protected layoutItems(): void;
    protected processData(): void;
    getContainer(): HTMLDivElement;
    protected formatArray(key: string): any;
    private getShapeSize;
    private getStyle;
    destroy(): void;
}
export {};
