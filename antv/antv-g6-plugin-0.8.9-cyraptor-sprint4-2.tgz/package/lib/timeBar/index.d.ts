import Base, { IPluginBaseConfig } from '../base';
import { TickCfg, SliderOption } from './trendTimeBar';
import { TimeBarSliceOption } from './timeBarSlice';
import { IG6GraphEvent, TimeBarType, IAbstractGraph as IGraph, ShapeStyle } from '@antv/g6-core';
import { Interval } from './trend';
import { ControllerCfg } from './controllerBtn';
export interface Callback extends IG6GraphEvent {
    originValue: number[];
    value: number[];
}
interface TrendConfig {
    readonly data: {
        date: string;
        value: string;
    }[];
    readonly x?: number;
    readonly y?: number;
    readonly width?: number;
    readonly height?: number;
    readonly smooth?: boolean;
    readonly isArea?: boolean;
    readonly lineStyle?: ShapeStyle;
    readonly areaStyle?: ShapeStyle;
    readonly interval?: Interval;
}
interface TimeBarConfig extends IPluginBaseConfig {
    readonly x?: number;
    readonly y?: number;
    readonly width?: number;
    readonly height?: number;
    readonly padding?: number;
    readonly type?: TimeBarType;
    readonly trend?: TrendConfig;
    readonly slider?: SliderOption;
    readonly tick?: TimeBarSliceOption | TickCfg;
    readonly controllerCfg?: ControllerCfg;
    readonly filterEdge?: boolean;
    readonly filterItemTypes?: string[];
    readonly containerCSS?: Object;
    readonly changeData?: boolean;
    rangeChange?: (graph: IGraph, minValue: string, maxValue: string) => void;
    getDate?: (d: any) => number;
    getValue?: (d: any) => number;
    shouldIgnore?: (itemType: 'node' | 'edge', model: any, dateRage: {
        min: number;
        max: number;
    }) => boolean;
}
export default class TimeBar extends Base {
    constructor(config?: TimeBarConfig);
    private cacheGraphData;
    getDefaultCfgs(): TimeBarConfig;
    /**
     * 初始化 TimeBar 的容器
     */
    initContainer(): void;
    init(): void;
    /**
     * 触发时间轴播放
     */
    play(): void;
    /**
     * 触发时间轴暂停
     */
    pause(): void;
    /**
     * 时间轴播放状态（播放/暂停）的切换
     */
    private togglePlay;
    private renderTrend;
    private filterData;
    private afterrenderListener;
    private valueChangeListener;
    changeData: (e: any) => void;
    private initEvent;
    destroy(): void;
}
export {};
